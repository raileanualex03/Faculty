# include "ui.h"
# include <iostream>
# include <string.h>
# include "repositoryFiles.h"
# include "tests.h"
int main()
{
	testAll();
	//char filename[32] = "input.txt";
	//RepositoryFiles repository{ filename };
	//RepositoryMemory repositoryAssistant{};
	//Controller controller{ repository , repositoryAssistant};
	//UserInterface ui{ controller };
	//ui.run();


	return 0;
}
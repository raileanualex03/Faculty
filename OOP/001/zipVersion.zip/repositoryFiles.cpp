#include "repositoryFiles.h"
# include <iostream>
# include <fstream>
# include "domain.h"


unsigned RepositoryFiles::addBot(const Bot& bot)
{
	if (this->existsBot(bot.getID()) == 1)
		return 0;
	std::ofstream f(this->filename, std::ios::app);
	f << bot;

	f.close();
	return 1;
}

unsigned RepositoryFiles::removeBot(const Bot& bot)
{
	
	Bot botRead;
	if (this->existsBot(bot.getID()) == 0)
		return 0;
	std::ifstream fin(this->filename);
	std::ofstream fout(this->filename);
	std::vector<Bot> vector;
	while (fin >> botRead) {
		if (botRead.getID() != bot.getID()) {
			vector.push_back(botRead);
		}
	}
	for (auto element : vector)
		fout << element;

	fin.close();
	fout.close();
	return 1;
}

unsigned RepositoryFiles::updateBot(const Bot& bot)
{
	Bot botRead;
	if (this->existsBot(bot.getID()) == 0)
		return 0;
	this->removeBot(bot);
	this->addBot(bot);

	return 1;
}

std::vector<Bot> RepositoryFiles::getElements()
{
	Bot botRead;
	std::vector<Bot> vector;
	std::ifstream fin(this->filename);
	while (fin >> botRead)
		vector.push_back(botRead);

	fin.close();
	return vector;
}

Bot RepositoryFiles::searchBot(const std::string ID)
{
	Bot botRead;
	std::ifstream fin(this->filename);
	while (fin >> botRead)
		if (botRead.getID() == ID) {
			fin.close();
			return botRead;
		}
}

unsigned RepositoryFiles::existsBot(const std::string ID)
{
	Bot botRead;
	std::ifstream fin(this->filename);
	while (fin >> botRead)
		if (botRead.getID() == ID) {
			fin.close();
			return 1;
		}
	fin.close();
	return 0;
}

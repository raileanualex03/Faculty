#pragma once
# include <vector>
#include "genericRepository.h"
class RepositoryFiles :
	public Repository
{
public:
	char filename[32];
	RepositoryFiles(char filename[32]) { strcpy(this->filename, filename); };

	unsigned addBot(const Bot& bot) override;

	unsigned removeBot(const Bot& bot) override;

	unsigned updateBot(const Bot& bot) override;

	std::vector<Bot> getElements() override;

	Bot searchBot(const std::string ID) override;
	
	unsigned existsBot(const std::string ID) override;
};


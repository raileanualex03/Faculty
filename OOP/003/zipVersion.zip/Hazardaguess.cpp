#include "Hazardaguess.h"
# include <qmessagebox.h>
#include <iostream>
Hazardaguess::Hazardaguess(Controller* controller, QWidget *parent)
	: QMainWindow(parent)
{
	this->controller = controller;
	ui.setupUi(this);
	this->ui.ModeA->setEnabled(false);
	this->ui.modeB->setEnabled(false);
	this->makeConnections();
}

void Hazardaguess::populateList()
{	
	// first clear it
	this->ui.botsListWidget->clear();
	
	vector<Bot> allBots = this->controller->getElements();
	int index = 0;
	for (Bot& bot : allBots){
		this->ui.botsListWidget->addItem(QString::fromStdString("Bot: " + bot.getID() + " - " + bot.getSize() + " - " + bot.getRadioactivityLevel()
			+ " - " + std::to_string(bot.getQuantityOfMicrofragments()) + " - " + bot.getDigitizedScan()));
		this->ui.botsListWidget->item(index)->setForeground(Qt::white);
		index++;
	}

}

void Hazardaguess::makeConnections()
{
	QObject::connect(this->ui.botsListWidget, &QListWidget::itemSelectionChanged, [this]() {
		int selectedIndex = this->getSelectedIndex();
		if (selectedIndex < 0)
			return;
		Bot bot = this->controller->getElements()[selectedIndex];
		this->ui.IDLineEdit->setText(QString::fromStdString(bot.getID()));
		this->ui.SizeLineEdit->setText(QString::fromStdString(bot.getSize()));
		this->ui.RadioactivityLevelLineEdit->setText(QString::fromStdString(bot.getRadioactivityLevel()));
		this->ui.QuantityOfMicrofragmentsLineEdit->setText(QString::fromStdString(std::to_string(bot.getQuantityOfMicrofragments())));
		this->ui.DigitizedScanLineEdit->setText(QString::fromStdString(bot.getDigitizedScan()));
		});

	QObject::connect(this->ui.addButton, &QPushButton::clicked, this, &Hazardaguess::addBot);
	QObject::connect(this->ui.DeleteButton, &QPushButton::clicked, this, &Hazardaguess::deleteBot);
	QObject::connect(this->ui.updateButton, &QPushButton::clicked, this, &Hazardaguess::updateBot);
	QObject::connect(this->ui.fileModeAButton, &QPushButton::clicked, this, &Hazardaguess::fileModeA);
	QObject::connect(this->ui.fileModeBButton, &QPushButton::clicked, this, &Hazardaguess::fileModeB);
	QObject::connect(this->ui.memoryModeAButton, &QPushButton::clicked, this, &Hazardaguess::memoryModeA);
	QObject::connect(this->ui.memoryModeBButton, &QPushButton::clicked, this, &Hazardaguess::memoryModeB);
	QObject::connect(this->ui.pushButton_4, &QPushButton::clicked, this, &Hazardaguess::startApplication);
	QObject::connect(this->ui.saveFilenameModeA, &QPushButton::clicked, this, &Hazardaguess::setFilenameModeA);
	QObject::connect(this->ui.saveFilenameModeB, &QPushButton::clicked, this, &Hazardaguess::setFilenameModeB);
	QObject::connect(this->ui.openButton, &QPushButton::clicked, this, &Hazardaguess::openFile);
	QObject::connect(this->ui.nextButton, &QPushButton::clicked, this, &Hazardaguess::showNext);
	QObject::connect(this->ui.saveBotModeB, &QPushButton::clicked, this, &Hazardaguess::saveModeB);
	QObject::connect(this->ui.showModeBButton, &QPushButton::clicked, this, &Hazardaguess::showModeBBots);
	QObject::connect(this->ui.pushButton, &QPushButton::clicked, this, &Hazardaguess::showCertainBots);

}

int Hazardaguess::getSelectedIndex() const
{
	QModelIndexList selectedIndexes = this->ui.botsListWidget->selectionModel()->selectedIndexes();
	if (selectedIndexes.size() == 0)
	{
		this->ui.IDLineEdit->clear();
		this->ui.SizeLineEdit->clear();
		this->ui.RadioactivityLevelLineEdit->clear();
		this->ui.QuantityOfMicrofragmentsLineEdit->clear();
		this->ui.DigitizedScanLineEdit->clear();

		return -1;


	}
	int selectedIndex = selectedIndexes.at(0).row();


	return selectedIndex;
}

void Hazardaguess::addBot()
{
	double quantityOfMicrofragments = 0;
	std::string id = this->ui.IDLineEdit->text().toStdString();
	std::string size = this->ui.SizeLineEdit->text().toStdString();
	std::string radioactivityLevel = this->ui.RadioactivityLevelLineEdit->text().toStdString();
	try {
		quantityOfMicrofragments = std::stod(this->ui.QuantityOfMicrofragmentsLineEdit->text().toStdString());
	}
	catch (...)
	{
		QMessageBox::critical(this, "Error", "Empty space");
		return;

	}
	std::string digitizedScan = this->ui.DigitizedScanLineEdit->text().toStdString();

	// the addition
	try {
		this->controller->addBot(id, size, radioactivityLevel, quantityOfMicrofragments, digitizedScan);
	}
	catch (ValidationException& e) {
		QMessageBox::critical(this, "Error", e.getMessage().c_str());
		return;
	}
	catch (ExistenceException& e) {
		QMessageBox::critical(this, "Error", e.getMessage().c_str());
		return;
	}
	// change in the GUI
	this->populateList();

	int lastElement = this->controller->getElements().size() - 1;
	this->ui.botsListWidget->setCurrentRow(lastElement);
	QMessageBox::information(this, "Succesfully added!", "The item has been added!");
}

void Hazardaguess::deleteBot()
{
	int selectedIndex = this->getSelectedIndex();
	if (selectedIndex < 0)
	{
		QMessageBox::critical(this, "Error", "No bot selected! ");
		return;
	}

	Bot bot = this->controller->getElements()[selectedIndex];
	this->controller->removeBot(bot.getID());

	// change in the GUI
	this->populateList();
	QMessageBox::information(this, "Succesfully removed!", "The item has been removed!");
}

void Hazardaguess::updateBot()
{
	double quantityOfMicrofragments;
	std::string id = this->ui.IDLineEdit->text().toStdString();
	std::string size = this->ui.SizeLineEdit->text().toStdString();
	std::string radioactivityLevel = this->ui.RadioactivityLevelLineEdit->text().toStdString();
	try {
		quantityOfMicrofragments = std::stod(this->ui.QuantityOfMicrofragmentsLineEdit->text().toStdString());
	}
	catch (...)
	{
		QMessageBox::critical(this, "Error", "Empty space");
		return;


	}
	std::string digitizedScan = this->ui.DigitizedScanLineEdit->text().toStdString();
	try {
		this->controller->updateBot(id, size, radioactivityLevel, quantityOfMicrofragments, digitizedScan);
	}
	catch (ValidationException& e) {
		QMessageBox::critical(this, "Error", e.getMessage().c_str());
	}
	catch (ExistenceException& e) {
		QMessageBox::critical(this, "Error", e.getMessage().c_str());
	}
	// change in the GUI
	this->populateList();

	int lastElement = this->controller->getElements().size() - 1;
	this->ui.botsListWidget->setCurrentRow(lastElement);
	QMessageBox::information(this, "Succesfully updated!", "The item has been updated!");
}

void Hazardaguess::fileModeA()
{
	this->ui.memoryModeAButton->setEnabled(false);
	// 1 will be for the repository file
	this->codeRepositoryModeA = 1;
}

void Hazardaguess::fileModeB()
{
	this->ui.memoryModeBButton->setEnabled(false);
	// 1 will be for the file
	this->codeRepositoryModeB = 1;
}

void Hazardaguess::memoryModeA()
{
	this->ui.fileModeAButton->setEnabled(false);
	// 2 will be for in memory;
	this->codeRepositoryModeA = 2;

}

void Hazardaguess::memoryModeB()
{
	this->ui.fileModeBButton->setEnabled(false);
	// 2 will be for in memory :)
	this->codeRepositoryModeB = 2;
}

void Hazardaguess::startApplication()
{
	if (this->codeRepositoryModeA == -1 || this->codeRepositoryModeB == -1) {
		QMessageBox::critical(this, "Error", "No button pressed");
		return;
	}
	if (this->codeRepositoryModeA == 1) {
		RepositoryFiles* repo = new RepositoryFiles();
		if (this->codeRepositoryModeB == 1) {
			RepositoryFiles* repoAssistant = new RepositoryFiles();
			Controller* controller = new Controller(repo, repoAssistant);
			this->controller = controller;
			
		}
		else {
			RepositoryMemory* repoAssistant = new RepositoryMemory();
			Controller* controller = new Controller(repo, repoAssistant);
			this->controller = controller;
			this->ui.filenameModeB->setEnabled(false);
			this->ui.saveFilenameModeB->setEnabled(false);
			this->ui.openButton->setEnabled(false);
			this->ui.openButton->setText("Open not available!");
		}


	}
	else {
		RepositoryMemory* repo = new RepositoryMemory();

		if (this->codeRepositoryModeB == 1) {
			RepositoryFiles* repoAssistant = new RepositoryFiles();
			Controller* controller =  new Controller(repo, repoAssistant);
			this->controller = controller;
			
			this->ui.filenameModeA->setEnabled(false);
			this->ui.saveFilenameModeA->setEnabled(false);
		}
		else {
			RepositoryMemory* repoAssistant = new RepositoryMemory();
			Controller* controller = new Controller(repo, repoAssistant);
			this->controller = controller;
			this->ui.filenameModeA->setEnabled(false);
			this->ui.saveFilenameModeA->setEnabled(false);
			this->ui.filenameModeB->setEnabled(false);
			this->ui.saveFilenameModeB->setEnabled(false);
		}
	}
	this->ui.pushButton_4->setEnabled(false);
	this->ui.Start->setEnabled(false);
	this->ui.ModeA->setEnabled(true);
	this->ui.modeB->setEnabled(true);

}

void Hazardaguess::setFilenameModeA()
{
	std::string filename;
	filename = this->ui.filenameModeA->text().toStdString();
	this->controller->setFilename(filename);
	this->populateList();
	this->ui.filenameModeA->setEnabled(false);
	this->ui.saveFilenameModeA->setEnabled(false);
}

void Hazardaguess::setFilenameModeB()
{
	std::string filename;
	filename = this->ui.filenameModeB->text().toStdString();
	this->controller->setFilenameAssistant(filename);

	this->ui.filenameModeB->setEnabled(false);
	this->ui.saveFilenameModeB->setEnabled(false);
}

void Hazardaguess::openFile()
{
	std::string command = "start ";
	std::string type = this->controller->getTypeAssistant();
	if (type == "html")
		command += "chrome " + this->controller->getFilenameAssistant();
	else if (type == "csv")
		command += " excel " + this->controller->getFilenameAssistant();
	else if (type == "txt")
		command += " notepad " + this->controller->getFilenameAssistant();
	
	system(command.c_str());
}

void Hazardaguess::populateListModeB(std::vector<Bot> bots)
{
	this->ui.botsModeBListWidget->clear();

	int index = 0;
	for (Bot bot: bots) {
			this->ui.botsModeBListWidget->addItem(QString::fromStdString("Bot: " + bot.getID() + " - " + bot.getSize() + " - " + bot.getRadioactivityLevel()
				+ " - " + std::to_string(bot.getQuantityOfMicrofragments()) + " - " + bot.getDigitizedScan()));
			this->ui.botsModeBListWidget->item(index)->setForeground(Qt::white);
			index++;
	}
}

void Hazardaguess::showNext()
{
	Bot bot;
	try {
		bot = this->controller->getNextBot();
	}
	catch (ExistenceException e) {
		QMessageBox::critical(this, "Error", e.getMessage().c_str());
		return;
	}
	std::vector<Bot> bots;
	bots.push_back(bot);
	this->populateListModeB(bots);
}

void Hazardaguess::saveModeB()
{
	std::string ID = this->ui.IDModeBLineEdit->text().toStdString();
	try {
		this->controller->assistantAddBot(ID);
	}
	catch (ExistenceException e) {
		QMessageBox::critical(this, "Error", e.getMessage().c_str());
	}
	QMessageBox::information(this, "Succesfully saved!", "The item has been saved!");
}

void Hazardaguess::showModeBBots()
{
	std::vector<Bot> bots = this->controller->assistantGetBots();
	this->populateListModeB(bots);
}

void Hazardaguess::showCertainBots()
{
	std::string size = this->ui.radioactivityLevelModeBEdit->text().toStdString();
	if (size.length() <= 0) {
		QMessageBox::critical(this, "Error", "No size provided");
		return;
	}
	std::string quantityString = this->ui.quantityModeBLineEdit->text().toStdString();
	if (quantityString.length() <= 0) {
		QMessageBox::critical(this, "Error", "No quantity provided");
		return;
	}
	double quantity = std::stod(quantityString);
	std::vector<Bot> bots = this->controller->getBotsWithCertainSize(size, quantity);
	this->populateListModeB(bots);
}





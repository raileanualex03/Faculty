#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_Hazardaguess.h"
#include "controller.h"

class Hazardaguess : public QMainWindow
{

public:
	Hazardaguess(Controller* controller, QWidget *parent = Q_NULLPTR);
	int codeRepositoryModeA = -1;
	int codeRepositoryModeB = -1;
private:
	Controller* controller;
	
	Ui::HazardaguessClass ui;

	void populateList();
	void makeConnections();

	int getSelectedIndex() const;
	void addBot();
	void deleteBot();
	void updateBot();

	void fileModeA();
	void fileModeB();

	void memoryModeA();
	void memoryModeB();

	void startApplication();
	
	void setFilenameModeA();
	void setFilenameModeB();

	void openFile();
	void populateListModeB(std::vector<Bot> bots);
	
	void showNext();

	void saveModeB();
	void showModeBBots();
	void showCertainBots();
};


#include <QtWidgets/QApplication>
#include "repositoryFiles.h"
#include "controller.h"
# include "Hazardaguess.h"

int main(int argc, char *argv[])
{
	QApplication app(argc, argv);
	app.setWindowIcon(QIcon("./21047.jpg"));

	RepositoryFiles* repo = new RepositoryFiles("test.txt");
	RepositoryFiles* repoAssistant =new RepositoryFiles();
	Controller *controller =  new Controller(repo, repoAssistant);
	
	Hazardaguess gui{controller};
	gui.show();

	return app.exec();
}
		